### requirements.txt
Python所需外部函示庫

### Procfile
Heroku執行的程序指令

### runtime.txt
環境設定

### app.json
應用資訊

